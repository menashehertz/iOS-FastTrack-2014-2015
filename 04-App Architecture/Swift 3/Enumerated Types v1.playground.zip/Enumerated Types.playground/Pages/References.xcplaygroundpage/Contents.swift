//: [Previous](@previous)

//: # References
//:
//: [\[1\]](http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/) *"The Swift Programming Language."*, http://developer.apple.com/library/ios/documentation/Swift/Conceptual/Swift_Programming_Language/ Apple Inc., Accessed 11-11-2016
//:
//: [\[2\]](https://appventure.me/2015/08/20/swift-pattern-matching-in-detail/) *"Match Me if you can: Swift Pattern Matching in Detail"*, https://appventure.me/2015/08/20/swift-pattern-matching-in-detail/, by BENEDIKT TERHECHTE, Accessed 11-11-2016
//:
//: ----
//:
//: ![logo](logo.png)
